module github.com/rodriveracom/ephemeral

go 1.25.0

require (
	github.com/dustin/go-humanize v1.0.1
	github.com/google/uuid v1.6.0
	github.com/mattn/go-isatty v0.0.24
	github.com/ncruces/go-strftime v1.0.0
	github.com/remyoudompheng/bigfft v0.0.0-20230129092748-24d4a6f8daec
	golang.org/x/sys v0.47.0
	modernc.org/libc v1.74.4
	modernc.org/mathutil v1.7.1
	modernc.org/memory v1.11.0
	modernc.org/sqlite v1.57.0
)
