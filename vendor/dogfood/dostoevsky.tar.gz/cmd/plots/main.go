// Command plots renders the charts in docs/img from the raw receipt lines in
// docs/*-results.txt. It uses only the standard library and is deterministic:
// the same receipts always produce the same bytes.
package main

import (
	"bufio"
	"flag"
	"fmt"
	"html"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

// trial is one receipt line: space separated key=value pairs.
type trial map[string]string

func (t trial) num(key string) (float64, bool) {
	v, err := strconv.ParseFloat(t[key], 64)
	return v, err == nil
}

// numAny reads the first of several alternative keys, written "a|b", that holds a
// number: the memory chart uses total_rss_KiB when a line has it (a server engine) and
// peakRSS_KiB otherwise.
func (t trial) numAny(keys string) (float64, bool) {
	for _, k := range strings.Split(keys, "|") {
		if v, ok := t.num(k); ok {
			return v, true
		}
	}
	return 0, false
}

// quantileKind says how a receipt line's percentiles were computed: "bin-upper-1pct" (the
// shared 1% histogram, an upper bound at most 1% above the true value) or "exact" (the sample
// itself, which every receipt written before the histogram is, and which carries no marker).
func quantileKind(t trial) string {
	if k := t["quantiles"]; k != "" {
		return k
	}
	return "exact"
}

// carriesPercentiles says whether a row has percentiles at all. A FAILED row (the driver's marker, or a
// worker's result=FAILED) and anything else without p50/p95/p99 has none, so it says nothing about how
// percentiles were computed and must not take part in the kind check.
func carriesPercentiles(t trial) bool {
	if t["failed"] == "1" {
		return false
	}
	for _, k := range []string{"p50_us", "p95_us", "p99_us"} {
		if _, ok := t[k]; ok {
			return true
		}
	}
	return false
}

// oneQuantileKind refuses a set of trials whose percentiles mean different things: a chart that
// mixed exact values with bin upper edges would compare numbers that are not the same quantity.
// Only rows that carry percentiles are looked at, so a run with a failed trial is not "mixed".
func oneQuantileKind(trials []trial) error {
	kinds := map[string]bool{}
	for _, t := range trials {
		if carriesPercentiles(t) {
			kinds[quantileKind(t)] = true
		}
	}
	if len(kinds) > 1 {
		return fmt.Errorf("the receipt mixes percentile kinds (quantiles=exact and quantiles=bin-upper-1pct); draw them as separate charts")
	}
	return nil
}

// parseTrials reads the key=value lines of one receipt. With a section name it
// keeps only the lines under that "# section" header (up to the next header) that
// start with trial=; with an empty name it keeps every line that has key=value pairs.
func parseTrials(path, section string) ([]trial, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []trial
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<16), 1<<20)
	in := section == "" || section == "*"
	for sc.Scan() {
		line := sc.Text()
		if section == "*" {
			// Raw benchmark output: every trial= line, whatever surrounds it.
			if !strings.HasPrefix(line, "trial=") {
				continue
			}
		} else if section != "" {
			if strings.HasPrefix(line, "# ") {
				in = strings.TrimPrefix(line, "# ") == section
				continue
			}
			if !in || !strings.HasPrefix(line, "trial=") {
				continue
			}
		}
		t := trial{}
		for _, field := range strings.Fields(line) {
			if field == "FAILED" {
				// A failed trial counts and is never dropped, but nothing after the marker is
				// read: the rest is a diagnostic, and may look like key=value pairs.
				t["failed"] = "1"
				break
			}
			if k, v, ok := strings.Cut(field, "="); ok {
				t[k] = v
				if k == "result" && v == "FAILED" {
					t["failed"] = "1" // a language worker's own verdict counts exactly like the driver's FAILED marker
				}
			}
		}
		if len(t) > 0 {
			out = append(out, t)
		}
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	if err := oneQuantileKind(out); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	return out, nil
}

func parseMeta(path string) (map[string]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	meta := map[string]string{}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if k, v, ok := strings.Cut(sc.Text(), "="); ok && !strings.HasPrefix(k, "#") {
			meta[strings.TrimSpace(k)] = strings.TrimSpace(v)
		}
	}
	return meta, sc.Err()
}

func median(v []float64) float64 {
	s := append([]float64(nil), v...)
	sort.Float64s(s)
	if len(s) == 0 {
		return 0
	}
	if len(s)%2 == 1 {
		return s[len(s)/2]
	}
	return (s[len(s)/2-1] + s[len(s)/2]) / 2
}

// series is one engine's values at each producer count.
type series struct {
	engine string
	values map[int][]float64
}

func collect(trials []trial, key string, scale float64) []series {
	byEngine := map[string]*series{}
	for _, t := range trials {
		w, err := strconv.Atoi(t["workers"])
		v, ok := t.numAny(key)
		if t["failed"] == "1" || t["engine"] == "" || err != nil || !ok {
			continue
		}
		s := byEngine[t["engine"]]
		if s == nil {
			s = &series{engine: t["engine"], values: map[int][]float64{}}
			byEngine[t["engine"]] = s
		}
		s.values[w] = append(s.values[w], v*scale)
	}
	var out []series
	for _, s := range byEngine {
		out = append(out, *s)
	}
	// A fixed order, Dostoevsky first, so an engine keeps its palette slot across charts.
	sort.Slice(out, func(i, j int) bool {
		a, b := engineRank(out[i].engine), engineRank(out[j].engine)
		if a != b {
			return a < b
		}
		return out[i].engine < out[j].engine
	})
	return out
}

// engineOrder fixes the series order and with it each engine's color.
var engineOrder = []string{"dostoevsky", "jetstream", "sqlite", "redis", "valkey", "kafka", "rabbitmq"}

func engineRank(e string) int {
	for i, x := range engineOrder {
		if x == e {
			return i
		}
	}
	return len(engineOrder)
}

// engineLabels and engineArch come from the receipt's meta file (label.<engine> and
// arch.<engine>) and say what a bar is and where it ran.
var (
	engineLabels = map[string]string{}
	engineArch   = map[string]string{}
)

// failedTrials counts FAILED trial lines per engine and producer count; the charts
// show them and never drop them. allowFailures lets a receipt with failures plot.
var (
	failedTrials   = map[string]map[int]int{}
	allowFailures  bool
	ignoredEngines []string
	// notShown lists the engines that are in the receipt but deliberately left out of the
	// charts with -ignore-engines; the footer and the description name them.
	notShown []string
)

type chart struct {
	file, title, unit, alt, note, explain string
	multiTitle                            string // title when more than two engines are charted
	lower                                 bool
	key                                   string
	scale                                 float64
	decimals                              int
}

var gateCharts = []chart{
	{file: "throughput.svg", title: "Synchronous publish throughput", unit: "messages per second", key: "records/s", scale: 1, decimals: 0,
		alt:  "Grouped bars of median messages per second at 1, 8 and 32 producers for Dostoevsky and embedded JetStream, with each trial as a dot.",
		note: "Higher is better."},
	{file: "memory.svg", title: "Peak process memory", multiTitle: "Peak memory, client plus server processes", unit: "MiB peak RSS", key: "total_rss_KiB|peakRSS_KiB", scale: 1.0 / 1024, decimals: 1, lower: true,
		alt:  "Grouped bars of median peak resident memory in MiB at 1, 8 and 32 producers for Dostoevsky and embedded JetStream, with each trial as a dot.",
		note: "Lower is better."},
	{file: "p99-latency.svg", title: "p99 publish latency", unit: "milliseconds", key: "p99_us", scale: 1.0 / 1000, decimals: 2, lower: true,
		alt:  "Grouped bars of median p99 publish-to-acknowledgement latency in milliseconds at 1, 8 and 32 producers for Dostoevsky and embedded JetStream, with each trial as a dot.",
		note: "Lower is better."},
	{file: "reopen.svg", title: "Reopen time", unit: "milliseconds", key: "reopen_ms", scale: 1, decimals: 1, lower: true,
		alt:     "Grouped bars of median time to reopen the store, in milliseconds, at 1, 8 and 32 producers for Dostoevsky and embedded JetStream, with each trial as a dot. The time stops before the records are verified.",
		note:    "Lower is better.",
		explain: "Dostoevsky replays its journal on open; where that time goes was not profiled."},
}

// writeArchitecture is cleared by -architecture=false for secondary hosts.
var writeArchitecture = true

func main() {
	receipt := flag.String("receipt", "docs/publisher-gate-results.txt", "raw trial lines of the publisher gate")
	metaPath := flag.String("meta", "docs/publisher-gate-meta.txt", "key=value description of the run that produced the receipt")
	sketchPath := flag.String("sketch", "docs/sketch-accuracy-results.txt", "sketch accuracy receipt; skipped when absent")
	out := flag.String("out", "docs/img", "output directory")
	section := flag.String("section", "gate", `receipt section to chart; "*" charts every trial= line of a raw log`)
	trialsPerPoint := flag.Int("trials", 5, "required trials per engine and producer count (0 disables the check)")
	flag.BoolVar(&writeArchitecture, "architecture", true, "also write architecture.svg")
	chartEngines := flag.String("engines", "dostoevsky,jetstream", "engines every chart must have, comma separated")
	ignore := flag.String("ignore-engines", "", "engines present in the receipt that are deliberately left out of the charts, comma separated")
	flag.BoolVar(&allowFailures, "allow-failures", false, "chart a receipt that has FAILED trials, showing them, instead of refusing it")
	summary := flag.Bool("summary", false, "print validated medians of a comparison log (-receipt) instead of drawing charts")
	producers := flag.String("expect-producers", "1,8,32", "producer counts every engine must have in -summary mode")
	engineList := flag.String("expect-engines", "", "engines that must each appear in -summary mode, comma separated (required)")
	allowIncomplete := flag.Bool("allow-incomplete", false, "in -summary mode, list problems and still print the medians")
	flag.Parse()
	if *summary {
		counts, err := parseProducers(*producers)
		var engines []string
		if err == nil {
			engines, err = parseEngines(*engineList)
		}
		if err == nil {
			err = summarize(os.Stdout, *receipt, *trialsPerPoint, counts, engines, *allowIncomplete)
		}
		if err != nil {
			fmt.Fprintln(os.Stderr, "plots:", err)
			os.Exit(1)
		}
		return
	}
	if engines, err := parseEngines(*chartEngines); err != nil {
		fmt.Fprintln(os.Stderr, "plots:", err)
		os.Exit(1)
	} else {
		expectedEngines = engines
	}
	if *ignore != "" {
		ignored, err := parseEngines(*ignore)
		if err != nil {
			fmt.Fprintln(os.Stderr, "plots:", err)
			os.Exit(1)
		}
		ignoredEngines = ignored
	}
	if err := run(*receipt, *section, *metaPath, *sketchPath, *out, *trialsPerPoint); err != nil {
		fmt.Fprintln(os.Stderr, "plots:", err)
		os.Exit(1)
	}
}

func run(receipt, section, metaPath, sketchPath, out string, want int) error {
	trials, err := parseTrials(receipt, section)
	if err != nil {
		return err
	}
	meta, err := parseMeta(metaPath)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(out, 0o755); err != nil {
		return err
	}
	if !allowFailures {
		if n := countFailedLines(trials); n > 0 {
			return fmt.Errorf("%s has %d FAILED trial lines; every failure must be shown, so plot it with -allow-failures or fix the run", receipt, n)
		}
	}
	// The engines checked are the ones in the receipt, not whatever -engines says: every engine
	// that appears must be expected or explicitly ignored, and every expected engine must appear.
	if err := checkEngineSet(trials, expectedEngines, ignoredEngines); err != nil {
		return fmt.Errorf("%s: %w", receipt, err)
	}
	if comparisonMode(expectedEngines) {
		if err := requireComparisonMeta(expectedEngines, meta); err != nil {
			from := metaPath
			if len(expectedEngines) > maxSeries { // the selection is at fault, not the metadata
				from = "-engines"
			}
			return fmt.Errorf("%s: %w", from, err)
		}
	}
	notShown = leftOut(trials, expectedEngines, ignoredEngines)
	engineLabels, engineArch = map[string]string{}, map[string]string{}
	for k, v := range meta {
		if e, ok := strings.CutPrefix(k, "label."); ok {
			engineLabels[e] = v
		}
		if e, ok := strings.CutPrefix(k, "arch."); ok {
			engineArch[e] = v
		}
	}
	failedTrials = map[string]map[int]int{}
	for _, t := range trials {
		if w, err := strconv.Atoi(t["workers"]); err == nil && t["failed"] == "1" && inEngines(t["engine"], expectedEngines) {
			if failedTrials[t["engine"]] == nil {
				failedTrials[t["engine"]] = map[int]int{}
			}
			failedTrials[t["engine"]][w]++
		}
	}
	if want > 0 {
		if err := checkGroups(trials, want); err != nil {
			return fmt.Errorf("%s: %w", receipt, err)
		}
		// Every chart needs its own metric in every group, or a bar and a winner
		// could be drawn from fewer trials than the receipt promises.
		for _, c := range gateCharts {
			if err := checkMetric(trials, c.key, want); err != nil {
				return fmt.Errorf("%s: %s: %w", receipt, c.file, err)
			}
		}
	}
	footer := footerLines(meta, receipt)
	if len(notShown) > 0 {
		footer = append(footer, notShownLine())
	}
	for _, c := range gateCharts {
		data := onlyEngines(collect(trials, c.key, c.scale), expectedEngines)
		if len(data) == 0 {
			return fmt.Errorf("%s: no %q values in the gate section of %s", c.file, c.key, receipt)
		}
		if err := os.WriteFile(filepath.Join(out, c.file), []byte(renderBars(c, data, footer)), 0o644); err != nil {
			return err
		}
	}
	if writeArchitecture {
		if err := os.WriteFile(filepath.Join(out, "architecture.svg"), []byte(renderArchitecture()), 0o644); err != nil {
			return err
		}
	}
	if sk, err := parseTrials(sketchPath, ""); err == nil {
		svg := renderSketch(sk, []string{"Receipt: " + sketchPath, "Command: " + meta["sketch_command"]})
		return os.WriteFile(filepath.Join(out, "sketch-accuracy.svg"), []byte(svg), 0o644)
	} else if !os.IsNotExist(err) {
		return err
	}
	fmt.Fprintln(os.Stderr, "plots: no", sketchPath, "so sketch-accuracy.svg was not written")
	return nil
}

func footerLines(meta map[string]string, receipt string) []string {
	var lines []string
	// A multi-engine receipt describes its own setup in footer.1, footer.2, ...
	for i := 1; ; i++ {
		l, ok := meta[fmt.Sprintf("footer.%d", i)]
		if !ok {
			break
		}
		lines = append(lines, l)
	}
	if len(lines) == 0 {
		lines = []string{
			fmt.Sprintf("%s; %s; Go %s; GOMAXPROCS=%s; CGO_ENABLED=%s", meta["machine"], meta["os"], meta["go"], meta["gomaxprocs"], meta["cgo"]),
			fmt.Sprintf("Payload %s bytes; %s records per trial; %s; one topic, one replica; JetStream %s", meta["payload_bytes"], meta["records"], meta["sync"], meta["jetstream"]),
		}
	}
	for i := 1; ; i++ { // note.1, note.2, ...: durability and provenance labels
		l, ok := meta[fmt.Sprintf("note.%d", i)]
		if !ok {
			break
		}
		lines = append(lines, l)
	}
	return append(lines, fmt.Sprintf("Receipt: %s. Command: %s", receipt, meta["command"]))
}

const (
	width                  = 760
	left, right, top, base = 72, 24, 80, 340
)

// Colors are CSS custom properties so the same file works in light and dark.
const style = `<style>
:root{--bg:#ffffff;--fg:#1f2328;--muted:#59636e;--grid:#d1d9e0;--a:#0b6bcb;--b:#c2410c}
@media (prefers-color-scheme:dark){:root{--bg:#0d1117;--fg:#e6edf3;--muted:#9198a1;--grid:#3d444d;--a:#58a6ff;--b:#f0883e}}
rect.bg{fill:var(--bg)}
text{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;fill:var(--fg)}
.m{fill:var(--muted)}.g{stroke:var(--grid);stroke-width:1}
.s0{fill:var(--a)}.s1{fill:var(--b)}.d0{fill:var(--fg);stroke:var(--a);stroke-width:1.5}.d1{fill:var(--fg);stroke:var(--b);stroke-width:1.5}
</style>`

// niceMax rounds up to 1, 2, 2.5, 5 or 10 times a power of ten.
func niceMax(v float64) float64 {
	if v <= 0 {
		return 1
	}
	p := 1.0
	for p*10 <= v {
		p *= 10
	}
	for p > v {
		p /= 10
	}
	for _, m := range []float64{1, 2, 2.5, 5, 10} {
		if m*p >= v {
			return m * p
		}
	}
	return 10 * p
}

func format(v float64, decimals int) string {
	s := strconv.FormatFloat(v, 'f', decimals, 64)
	if decimals == 0 {
		return commas(s)
	}
	return s
}

func commas(s string) string {
	n := len(s)
	if n <= 3 {
		return s
	}
	var b strings.Builder
	for i, r := range s {
		if i > 0 && (n-i)%3 == 0 {
			b.WriteByte(',')
		}
		b.WriteRune(r)
	}
	return b.String()
}

func label(engine string) string {
	if l, ok := engineLabels[engine]; ok {
		return l
	}
	switch engine {
	case "dostoevsky":
		return "Dostoevsky"
	case "jetstream":
		return "Embedded JetStream"
	}
	return engine
}

func renderBars(c chart, data []series, footer []string) string {
	// Comparison rendering follows the declared engines, not how many have data: any engine
	// beyond dostoevsky and jetstream, at any count, means comparison mode.
	if len(data) > 2 || comparisonMode(expectedEngines) {
		return renderMulti(c, data, footer)
	}
	producers := map[int]bool{}
	maxV := 0.0
	for _, s := range data {
		for w, vs := range s.values {
			producers[w] = true
			for _, v := range vs {
				if v > maxV {
					maxV = v
				}
			}
		}
	}
	for _, byWorkers := range failedTrials { // a count where every trial failed still has its place
		for w := range byWorkers {
			producers[w] = true
		}
	}
	var ws []int
	for w := range producers {
		ws = append(ws, w)
	}
	sort.Ints(ws)
	step, steps := ticks(maxV)
	top1 := step * float64(steps)
	plotW := float64(width - left - right)
	verdict := winners(data, c.lower)
	subtitle := []string{c.unit + ". Bars are medians; dots are trials.", c.note + " " + verdict}
	if c.explain != "" && losing(data, c.lower) {
		subtitle[1] += " " + c.explain
	}
	subLines := wrap(subtitle, 100)
	// A subtitle that wraps to three lines must not run into the top gridline: the plot starts below
	// its last line (two-line subtitles leave the plot where it always was).
	plotTop := float64(top)
	if need := float64(46+15*(len(subLines)-1)) + 14; need > plotTop {
		plotTop = need
	}
	plotH := float64(base) - plotTop
	y := func(v float64) float64 { return float64(base) - v/top1*plotH }

	var b strings.Builder
	footer = wrap(footer, 112)
	groupW := plotW / float64(len(ws))
	shift := 12 * failureRows(data, ws, groupW) // zero without failures, so those charts do not change
	h := base + 74 + shift + 15*len(footer) + 10
	fmt.Fprintf(&b, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-labelledby="t d">`+"\n", width, h, width, h)
	fmt.Fprintf(&b, "<title id=\"t\">%s</title><desc id=\"d\">%s</desc>\n%s\n", html.EscapeString(c.title), html.EscapeString(c.alt+" "+verdict+notShownSentence()), style)
	fmt.Fprintf(&b, `<text x="%d" y="26" font-size="18" font-weight="600">%s</text>`+"\n", left, html.EscapeString(c.title))
	for i, line := range subLines {
		fmt.Fprintf(&b, `<text x="%d" y="%d" font-size="12" class="m">%s</text>`+"\n", left, 46+i*15, html.EscapeString(line))
	}
	for i := 0; i <= steps; i++ {
		v := step * float64(i)
		fmt.Fprintf(&b, `<line class="g" x1="%d" x2="%d" y1="%.1f" y2="%.1f"/><text class="m" x="%d" y="%.1f" font-size="11" text-anchor="end">%s</text>`+"\n",
			left, width-right, y(v), y(v), left-8, y(v)+4, format(v, stepDecimals(step)))
	}
	barW := groupW * 0.3
	for gi, w := range ws {
		gx := float64(left) + groupW*float64(gi)
		fmt.Fprintf(&b, `<text x="%.1f" y="%d" font-size="13" text-anchor="middle">%d producer%s</text>`+"\n", gx+groupW/2, base+22, w, plural(w))
		for i, line := range failureLines(data, w, groupW) {
			fmt.Fprintf(&b, `<text x="%.1f" y="%d" font-size="10" class="f">%s</text>`+"\n", gx+6, base+34+i*12, html.EscapeString(line))
		}
		for si, s := range data {
			vs := s.values[w]
			if len(vs) == 0 {
				continue
			}
			m := median(vs)
			x := gx + groupW/2 + (float64(si)-float64(len(data))/2)*(barW+6) + 3
			fmt.Fprintf(&b, `<rect class="s%d" x="%.1f" y="%.1f" width="%.1f" height="%.1f"><title>%s, %d producer%s: median %s</title></rect>`+"\n",
				si, x, y(m), barW, float64(base)-y(m), label(s.engine), w, plural(w), format(m, c.decimals))
			fmt.Fprintf(&b, `<text x="%.1f" y="%.1f" font-size="12" text-anchor="middle" font-weight="600">%s</text>`+"\n", x+barW/2, y(m)-8-dotRoom(vs, y, m), format(m, c.decimals))
			sorted := append([]float64(nil), vs...)
			sort.Float64s(sorted)
			for ti, v := range sorted {
				dx := x + barW/2 + (float64(ti)-float64(len(sorted)-1)/2)*7
				fmt.Fprintf(&b, `<circle class="d%d" cx="%.1f" cy="%.1f" r="3"/>`+"\n", si, dx, y(v))
			}
		}
	}
	for si, s := range data {
		lx := left + si*190
		fmt.Fprintf(&b, `<rect class="s%d" x="%d" y="%d" width="12" height="12"/><text x="%d" y="%d" font-size="12">%s</text>`+"\n", si, lx, base+40+shift, lx+18, base+50+shift, label(s.engine))
	}
	for i, line := range footer {
		fmt.Fprintf(&b, `<text class="m" x="%d" y="%d" font-size="10.5">%s</text>`+"\n", left, base+74+shift+i*15, html.EscapeString(line))
	}
	b.WriteString("</svg>\n")
	return withBackground(b.String())
}

// withBackground paints a page-colored rectangle behind everything, so text
// stays readable on a page whose theme differs from the viewer's color scheme.
func withBackground(svg string) string {
	return strings.Replace(svg, "</style>\n", "</style>\n<rect class=\"bg\" width=\"100%\" height=\"100%\"/>\n", 1)
}

// ticks returns a round step (1, 2 or 5 times a power of ten) and the number of
// steps needed to cover max, with at most six steps.
func ticks(max float64) (step float64, n int) {
	if max <= 0 {
		return 1, 1
	}
	p := 1.0
	for p*10 <= max {
		p *= 10
	}
	for p > max {
		p /= 10
	}
	for _, mult := range []float64{0.2, 0.5, 1, 2, 5, 10} {
		step = mult * p
		n = int(max/step + 0.999999)
		if n <= 6 {
			return step, n
		}
	}
	return 10 * p, 1
}

// wrap breaks each line at spaces so none exceeds max characters.
func wrap(lines []string, max int) []string {
	var out []string
	for _, l := range lines {
		for len(l) > max {
			cut := strings.LastIndex(l[:max], " ")
			if cut <= 0 {
				cut = max
			}
			out = append(out, strings.TrimSpace(l[:cut]))
			l = strings.TrimSpace(l[cut:])
		}
		out = append(out, l)
	}
	return out
}

// dotRoom lifts the value label above the highest trial dot.
func dotRoom(vs []float64, y func(float64) float64, m float64) float64 {
	hi := m
	for _, v := range vs {
		if v > hi {
			hi = v
		}
	}
	return y(m) - y(hi)
}

func plural(n int) string {
	if n == 1 {
		return ""
	}
	return "s"
}

// medians returns each engine's median at each producer count.
func medians(data []series) map[string]map[int]float64 {
	out := map[string]map[int]float64{}
	for _, s := range data {
		out[s.engine] = map[int]float64{}
		for w, vs := range s.values {
			out[s.engine][w] = median(vs)
		}
	}
	return out
}

// bestAt returns the engine with the best median at each producer count,
// leaving out counts where the two best medians are equal.
func bestAt(data []series, lower bool) map[int]string {
	if len(data) < 2 {
		return map[int]string{} // nobody to beat
	}
	med := medians(data)
	counts := map[int]bool{}
	for _, s := range data {
		for w := range s.values {
			counts[w] = true
		}
	}
	best := map[int]string{}
	for w := range counts {
		var name string
		var value float64
		tie := false
		complete := true
		for _, s := range data {
			if _, ok := med[s.engine][w]; !ok {
				complete = false
			}
		}
		if !complete {
			// A winner needs an opponent at this producer count.
			continue
		}
		for _, s := range data {
			v := med[s.engine][w]
			switch {
			case name == "" || (lower && v < value) || (!lower && v > value):
				name, value, tie = s.engine, v, false
			case v == value:
				tie = true
			}
		}
		if name != "" && !tie {
			best[w] = name
		}
	}
	return best
}

// winners states, from the data, which engine has the better median at which
// producer counts, for example "Dostoevsky wins at 1 and 8 producers."
func winners(data []series, lower bool) string {
	best := bestAt(data, lower)
	var parts []string
	for _, s := range data {
		var ws []int
		for w, name := range best {
			if name == s.engine {
				ws = append(ws, w)
			}
		}
		if len(ws) == 0 {
			continue
		}
		sort.Ints(ws)
		parts = append(parts, fmt.Sprintf("%s wins at %s.", label(s.engine), producerList(ws)))
	}
	return strings.Join(parts, " ")
}

// losing reports whether Dostoevsky is not the best engine at some producer count.
func losing(data []series, lower bool) bool {
	best := bestAt(data, lower)
	for _, name := range best {
		if name != "dostoevsky" {
			return true
		}
	}
	return false
}

func producerList(ws []int) string {
	var s []string
	for _, w := range ws {
		s = append(s, strconv.Itoa(w))
	}
	list := s[0]
	switch len(s) {
	case 1:
		return list + " producer" + plural(ws[0])
	case 2:
		list = s[0] + " and " + s[1]
	default:
		list = strings.Join(s[:len(s)-1], ", ") + " and " + s[len(s)-1]
	}
	return list + " producers"
}

var (
	expectedEngines   = []string{"dostoevsky", "jetstream"}
	expectedProducers = []int{1, 8, 32}
)

// checkGroups fails loudly when a chart would draw fewer bars or dots than the
// receipt promises: every engine at every producer count must have exactly want
// distinct trials.
func checkGroups(trials []trial, want int) error {
	type group struct {
		engine  string
		workers int
	}
	ids := map[group]map[string]bool{}
	for _, t := range trials {
		w, err := strconv.Atoi(t["workers"])
		if t["engine"] == "" || err != nil {
			continue
		}
		g := group{t["engine"], w}
		if ids[g] == nil {
			ids[g] = map[string]bool{}
		}
		if ids[g][t["trial"]] {
			return fmt.Errorf("duplicate trial %s for %s at %d producers", t["trial"], g.engine, g.workers)
		}
		ids[g][t["trial"]] = true
	}
	for _, e := range expectedEngines {
		for _, w := range expectedProducers {
			n, ok := ids[group{e, w}]
			if !ok {
				return fmt.Errorf("missing trials for %s at %d producers", e, w)
			}
			if len(n) != want {
				return fmt.Errorf("%s at %d producers has %d trials, want %d", e, w, len(n), want)
			}
		}
	}
	return nil
}

// checkMetric requires want usable, finite values of key for every expected
// engine at every expected producer count.
func checkMetric(trials []trial, key string, want int) error {
	type group struct {
		engine  string
		workers int
	}
	usable := map[group]int{}
	failed := map[group]int{}
	for _, t := range trials {
		w, err := strconv.Atoi(t["workers"])
		if err != nil {
			continue
		}
		if t["failed"] == "1" {
			failed[group{t["engine"], w}]++
			continue
		}
		v, ok := t.numAny(key)
		if !ok || math.IsNaN(v) || math.IsInf(v, 0) {
			continue
		}
		usable[group{t["engine"], w}]++
	}
	for _, e := range expectedEngines {
		for _, w := range expectedProducers {
			g := group{e, w}
			n, f := usable[g], failed[g]
			if n == want || (allowFailures && n+f == want) {
				continue
			}
			if f > 0 {
				return fmt.Errorf("%s at %d producers has %d usable %q values and %d failed trials, want %d usable", e, w, n, key, f, want)
			}
			return fmt.Errorf("%s at %d producers has %d usable %q values, want %d", e, w, n, key, want)
		}
	}
	return nil
}

func inEngines(e string, list []string) bool {
	for _, x := range list {
		if x == e {
			return true
		}
	}
	return false
}

// onlyEngines keeps the series of the charted engines: engines left out with
// -ignore-engines are not drawn.
func onlyEngines(data []series, charted []string) []series {
	var out []series
	for _, s := range data {
		if inEngines(s.engine, charted) {
			out = append(out, s)
		}
	}
	return out
}
